# popular-movies-app
#Change API key in gradle.properties file
